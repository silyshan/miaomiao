package com.example.myloverspace;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class EditActivity extends BaseActivity {

    private NoteDatabase dbHelper;
    private Context context = this;

    private EditText et;

    private String old_content = "";
    private String old_time = "";
    private int old_Tag = 1;
    private long id = 0;
    private int openMode = 0;
    private int tag = 1;
    private boolean tagChange = false;
    private Toolbar myToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_layout);

        myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);  //设置toolbar取代actionbar

        //tag标签
        Spinner mySpinner = (Spinner) findViewById(R.id.spinner);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        List<String> tagList = Arrays.asList(sharedPreferences.getString("tagListString", null).split("_")); //获取tags
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(this, R.layout.spinner_item, tagList);
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tag = (int) id + 1;
                tagChange = true;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        if (isNightMode())
            myToolbar.setNavigationIcon(getDrawable(R.drawable.ic_keyboard_arrow_left_white_24dp));
        else myToolbar.setNavigationIcon(getDrawable(R.drawable.ic_keyboard_arrow_left_black_24dp));


        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                if (openMode == 4) {
                    if (et.getText().toString().length() == 0) {
                        intent.putExtra("mode", -1); //nothing new happens.
                    } else {
                        intent.putExtra("mode", 0); // new one note;
                        intent.putExtra("content", et.getText().toString());
                        intent.putExtra("time", dateToStr());
                        intent.putExtra("tag", tag);
                    }
                } else {
                    if (et.getText().toString().equals(old_content) && !tagChange)
                        intent.putExtra("mode", -1); // edit nothing
                    else {
                        intent.putExtra("mode", 1); //edit the content
                        intent.putExtra("content", et.getText().toString());
                        intent.putExtra("time", dateToStr());
                        intent.putExtra("id", id);
                        intent.putExtra("tag", tag);
                    }
                }
                setResult(RESULT_OK, intent);
                finish();//返回
            }
        });
        et = (EditText)findViewById(R.id.et);

        Intent getIntent = getIntent();

        openMode = getIntent.getIntExtra("mode", 0);
        if (openMode == 3) {//打开已存在的note
            id = getIntent.getLongExtra("id", 0);
            old_content = getIntent.getStringExtra("content");
            old_time = getIntent.getStringExtra("time");
            old_Tag = getIntent.getIntExtra("tag", 1);
            et.setText(old_content);
            et.setSelection(old_content.length());
            mySpinner.setSelection(old_Tag - 1);
        }
    }


    @Override
    protected void needRefresh(){
        //Log.d(TAG, "needRefresh: Edit");
        setNightMode();
        startActivity(new Intent(this, EditActivity.class));
        finish();
    }


            public boolean onKeyDown(int keyCode, KeyEvent event) {

                super.onKeyDown(keyCode, event);
                if (keyCode == KeyEvent.KEYCODE_HOME) {
                    return true;
                } else if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    Intent intent = new Intent();
                    if (openMode == 4) {
                        if (et.getText().toString().length() == 0) {
                            intent.putExtra("mode", -1); //nothing new happens.
                        } else {
                            intent.putExtra("mode", 0); // new one note;
                            intent.putExtra("content", et.getText().toString());
                            intent.putExtra("time", dateToStr());
                            intent.putExtra("tag", tag);
                        }
                    } else {
                        if (et.getText().toString().equals(old_content) && !tagChange)
                            intent.putExtra("mode", -1); // edit nothing
                        else {
                            intent.putExtra("mode", 1); //edit the content
                            intent.putExtra("content", et.getText().toString());
                            intent.putExtra("time", dateToStr());
                            intent.putExtra("id", id);
                            intent.putExtra("tag", tag);
                        }
                    }
                    setResult(RESULT_OK, intent);
                    finish();
                    return true;
                }
                return super.onKeyDown(keyCode, event);
            }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    public boolean onOptionsItemSelected(MenuItem item){
        final Intent intent = new Intent();
        switch (item.getItemId()){
            case R.id.delete:
                new AlertDialog.Builder(EditActivity.this)
                        .setMessage("delete?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                if(openMode == 4){ //new note
                                    intent.putExtra("mode",-1);
                                    setResult(RESULT_OK,intent);
                                }
                                else{   //existing note
                                    intent.putExtra("mode",2);
                                    intent.putExtra("id",id);
                                    setResult(RESULT_OK,intent);
                                }
                                finish();
                            }
                        }).setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.dismiss();
                    }
                }).create().show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }





    public String dateToStr(){
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return simpleDateFormat.format(date);
    }
}
